<?php
error_reporting(0);
include 'koneksi.php';

if(isset($_POST['edit'])){
	$admin = $_POST['admin'];
	$nama = $_POST['nama'];
	$deskripsi = $_POST['deskripsi'];
	


	$query = "UPDATE donasi set nama = '$nama', deskripsi = '$deskripsi' where admin = '$admin' ";
	$result = mysqli_query ($koneksi, $query);

	if (!$result){
		die("Data gagal di ubah; ".mysqli_errno($koneksi).mysqli_error($koneksi));
	}
	else{
		echo "<script>alert('Data Berhasil Diubah');window.location.href='share.php'</script>";
	}
}
?>