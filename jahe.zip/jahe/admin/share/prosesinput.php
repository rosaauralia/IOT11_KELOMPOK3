<?php
error_reporting(0);
include 'koneksi.php';

if (isset($_POST['simpan'])){

    $admin = $_POST['admin'];
    $nama = $_POST['nama'];
    $deskripsi = $_POST['deskripsi'];
   

    
        $query = "INSERT INTO donasi VALUES ('$admin','$nama','$deskripsi')";
        $result = mysqli_query($koneksi, $query);
        if (!$result) {
            die("Query Gagal dijalankan : " . mysqli_errno($koneksi)." - ". mysqli_error($koneksi));        
        }
        else
        {
            echo "<script>
            alert('Data Berhasil Ditambah');window.location.href='share.php'</script>";
        }
        
    
}

 ?>